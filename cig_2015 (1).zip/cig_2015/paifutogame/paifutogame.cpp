using namespace std; 
#include "engine.h"

double sim_threshold;

double **tenpai_wei;
double **matiyomi_wei;
double *tokuten_wei;
int *op_list;
//double sutehai_pro[34][5][34];
double n_seme_pro[10][4096][18];

boost::unordered_map<std::string,double> kata_list;
boost::unordered_map<std::string,int> tenpai_pre_list;
boost::unordered_map<std::string,int> matiyomi_list;
boost::unordered_map<std::string,int> tokuten_pre_list;

int main(int argc,char* argv[])
{

	init_engine();
	//return 0;

	int i=0,ri_ti=0,ma=-1,aka,mae=0,jissai=1;
	int oya[4]={0};
	int rank[4]={0};
	int ura_dora[5]={0};
	int mae_kind=-1;
	int temp_tokuten[4]={0};
	int number_of_kan=0;
	int to_pi=0;

	field game_field;
	game_field.ri_ti_bou=0;game_field.bafuu=27;game_field.honba=0;game_field.kyoku=0;
	player tatya[4];
	boost::unordered_map<std::string,int> name;
	#pragma warning(disable:4996)
	int yonma=1;
	int sutehai[34]={0};
	
	vector<string> result;
	vector<string> result_paifu;
	vector<string> paifu;
	vector<int> dora;
	vector<int> naki_pattern;
	vector<string> feature;
	vector<string> feature2;

	int make_test=0;//
	int test_num=0;
	int j=0;
	string str;

	std::ofstream ofs("concordance_rate.txt");

	
	sim_threshold=0.2;
	int seikai[3]={0};
	int mondaisuu=0;
	int max_mon=10000;

	string filename="result.txt";
	std::ofstream ofs2(filename);	
	
	ifstream ifs("201401.txt");

	if(ifs.fail()){cerr << "File do not exist.\n";while(1){}exit(0);}
	while(getline(ifs, str) && mondaisuu<max_mon-1)
	{
		boost::split(result,str,boost::is_space());
		//for(int j=0;j<result.size();j++){cout<<j<<" "<<result[j]<<endl;}	
		//printf("%d\n",result.size());
		if(yonma==1 || ( (signed)result.size()>1 && result[0]=="-----") || ((signed)result.size()>3 && jissai==1 && result[0].substr(0,5)=="====="))
		{
			if((signed)result.size()>1 && result[0]=="-----"){yonma=0;jissai=1;}
			else if((signed)result.size()>3 && jissai==1 && result[0].substr(0,5)=="=====")
			{
				name.erase(name.begin(),name.end());
				game_field.kyoku=-1;
				game_field.honba=-1;
				if(result[3].find("w")!=string::npos){game_field.game_long=4;}
				{game_field.game_long=8;}
				if(result[3].find("�R")==string::npos && result[3].find("��")!=string::npos && result[3].find("��")!=string::npos){yonma=1;}
				if(mondaisuu<max_mon){ofs2<<result[6]<<endl;}
				cout<<result[6]<<endl;
			}
			else if(result.size()>4 && result[2].find("��")!=string::npos)
			{
			   string play_name=result[3];
			   i=3;
			   while(name.count(play_name)==0){i++;play_name+=result[i];}
			   rank[name[play_name]]=toInt(result[2].substr(0,1));
			}
			else if((signed)result.size()>3 && jissai==1 && (result[2].substr(0,1)=="w" || result[2].substr(0,1)=="x" || result[2].substr(0,1)=="y"))
			{
				if(result[2].substr(0,1)=="w"){game_field.bafuu=27;}
			       	else if(result[2].substr(0,1)=="x"){game_field.bafuu=28;}
				else if(result[2].substr(0,1)=="y"){game_field.bafuu=29;}
				
				if(game_field.honba==toInt(result[3].substr(0,result[3].find("�{"))) && game_field.kyoku==toInt( result[2].substr(1,1))+(game_field.bafuu/28)*4 )
				{
					string play_name;
					for(i=5;i<(signed)result.size();i++)
					{
					  play_name+=result[i];
					  if(name.count(play_name)!=0)
					  {
					    i++;
					    while(result[i]==""){i++;}
					    temp_tokuten[name[play_name]]+=toInt(result[i]);
					    play_name="";
					  }
					}
				}
				else
				{
					jissai=1;
					result_paifu.clear();
					paifu.clear();
					number_of_kan=0;
					game_field.nokori_maisuu=70;
					game_field.haitei=0;
					game_field.dora_num=1;
					game_field.kan_flag=0;
					game_field.mieta_aka_hai=0;
					for(ri_ti=0;ri_ti<37;ri_ti++){game_field.sutehai_sarasi[ri_ti]=0;}
					mae_kind=-1;
					for(ri_ti=0;ri_ti<4;ri_ti++)
					{
						for(i=0;i<4;i++)
						{
							tatya[ri_ti].fu_ro[i]=-1;
							tatya[ri_ti].fu_ro_sute[i]=-1;
						}
						tatya[ri_ti].aka_moti=0;
						tatya[ri_ti].aka_fu_ro=0;
						tatya[ri_ti].fu_ro_suu=0;
						tatya[ri_ti].ippatu=0;
						tatya[ri_ti].aka_moti=0;
						tatya[ri_ti].ri_ti_flag=0;
						tatya[ri_ti].tenho=1;
						tatya[ri_ti].fold_flag=0;
						tatya[ri_ti].ri_ti_sute=-1;
						tatya[ri_ti].tedasi.clear();
						tatya[ri_ti].sutehai.clear();
					}
					ri_ti=0;
					ma=-1;
					for(i=0;i<4;i++)
					{
						tatya[0].ri_ti_flag=0;
						oya[i]=0;
						tatya[i].tensuu+=temp_tokuten[i];
						temp_tokuten[i]=0;
					}
					//cout<<result.size()<<endl;
					game_field.kyoku=toInt( result[2].substr(1,1));
					if(game_field.bafuu!=27){game_field.kyoku+=4;}
					game_field.honba=toInt(result[3].substr(0,result[3].find("�{")));
					
					game_field.ri_ti_bou=toInt(result[3].substr(result[3].find("�`")+2,result[3].size()-result[3].find("�`")-3));
				    //printf("kyoku %d honba %d %d\n",game_field.kyoku,game_field.honba,game_field.ri_ti_bou);
					if(mondaisuu<max_mon){ofs2<<"kyoku"<<game_field.kyoku<<"honba"<<game_field.honba<<endl;}
					string play_name;
					for(i=5;i<(signed)result.size();i++)
					{
					  play_name+=result[i];
					  if(name.count(play_name)!=0)
					  {
					    i++;
					    while(result[i]==""){i++;}
					    temp_tokuten[name[play_name]]+=toInt(result[i]);
					    play_name="";
					  }
					}	
				}
			}
			else if((signed)result.size()>3 && jissai==1 && result[3]=="25000")
			{
				name.clear();
				int play_num=0;
				string play_name;
				int sp_k=0;
				for(i=4;i<(signed)result.size();i++)
				{
				  int sl_f=0;
				  int sl_l=0;
				  for(int j=(signed)result[i].size()-1;j>=0;j--)
				  {
				    if(result[i].substr(j,1)=="/"){sl_f++;}
				    if(sl_f==2){sl_l=j;j=-1;}
				  }
				  if(sl_f==2 && i+1<(signed)result.size() && result[i+1].find("R")!=string::npos)
				  {
				    if(sp_k==0)
				    {play_name=result[i].substr(3,sl_l-3);}
				    else{play_name+=result[i].substr(0,sl_l);}
				    name[play_name]=play_num;tatya[play_num].tensuu=25000;temp_tokuten[play_num]=0;
				    play_num++;
				    play_name="";
				    sp_k=0;
				  }
				  else if(result[i].find("]")!=string::npos && sp_k==0)
				  {
				    sp_k=1;
				    play_name=result[i].substr(3,result[i].size()-3);
				  }
				  else if(sp_k==1)
				  {
				    play_name+=result[i];
				  }
				}
			}
			else if((signed)result.size()>3 && jissai==1 && result[4].substr(0,1)=="[" &&  result[4].substr(1,1)!="o" && (result[4].substr(2,1)=="w" ||result[4].substr(2,1)=="x" ||result[4].substr(2,1)=="y" ||result[4].substr(2,1)=="z" ))
			{
				//cout<<result[4].substr(4,1);
				int pl=toInt(result[4].substr(1,1));
				pl--;
				if(result[4].substr(2,1)=="w"){tatya[pl].jifuu=27;}
				else if(result[4].substr(2,1)=="x"){tatya[pl].jifuu=28;}
				else if(result[4].substr(2,1)=="y"){tatya[pl].jifuu=29;}
				else if(result[4].substr(2,1)=="z"){tatya[pl].jifuu=30;}
	
				for(i=0;i<34;i++)
				{
					tatya[pl].hai[i]=0;
					tatya[pl].genbutu[i]=0;
					tatya[pl].tegawari[i]=3;
					sutehai[i]=0;
				}
				i=0;
				int k=4;
				if(result[4].substr(2,1)=="w"){oya[pl]=1;}
				while(i<13)
				{
					if(result[4].substr(k,1)=="1" ||result[4].substr(k,1)=="2" ||result[4].substr(k,1)=="3" ||result[4].substr(k,1)=="4" ||result[4].substr(k,1)=="5" ||result[4].substr(k,1)=="6" ||result[4].substr(k,1)=="7" ||result[4].substr(k,1)=="8" ||result[4].substr(k,1)=="9" )
					{
						if(result[4].substr(k+1,1)=="m" || result[4].substr(k+1,1)=="M")
						{tatya[pl].hai[toInt(result[4].substr(k,1))-1]++;}
						else if(result[4].substr(k+1,1)=="p" || result[4].substr(k+1,1)=="P")
						{tatya[pl].hai[toInt(result[4].substr(k,1))+8]++;}
						else if(result[4].substr(k+1,1)=="s" || result[4].substr(k+1,1)=="S")
						{tatya[pl].hai[toInt(result[4].substr(k,1))+17]++;}
						if(result[4].substr(k+1,1)=="M")
						{tatya[pl].aka_moti++;}
						else if(result[4].substr(k+1,1)=="P")
						{tatya[pl].aka_moti+=2;}
						else if(result[4].substr(k+1,1)=="S")
						{tatya[pl].aka_moti+=4;}
						i++;
						k+=2;
					}
					else if(result[4].substr(k,1)=="w"){tatya[pl].hai[27]++;i++;k++;}
					else if(result[4].substr(k,1)=="x"){tatya[pl].hai[28]++;i++;k++;}
					else if(result[4].substr(k,1)=="y"){tatya[pl].hai[29]++;i++;k++;}
					else if(result[4].substr(k,1)=="z"){tatya[pl].hai[30]++;i++;k++;}
					else if(result[4].substr(k,1)=="h"){tatya[pl].hai[31]++;i++;k++;}
					else if(result[4].substr(k,1)=="i"){tatya[pl].hai[32]++;i++;k++;}
					else if(result[4].substr(k,1)=="j"){tatya[pl].hai[33]++;i++;k++;}
				}//while(j<12)
			}
			else if((signed)result.size()>3 &&jissai==1 && result[4].substr(0,1)=="[" &&  result[4].substr(1,1)=="o")
			{
				i=3;
				dora.clear();
				while(i<(signed)result[4].size())
				{
					if(hai_kind_string_to_33(result[4].substr(i,1),&aka)!=-1)
					{
						dora.push_back(hai_kind_string_to_33(result[4].substr(i,1),&aka));
						game_field.sutehai_sarasi[hai_kind_string_to_37(result[4].substr(i,1),&aka)]++;
						i++;
					}
					else
					{
						dora.push_back(hai_kind_string_to_33(result[4].substr(i,2),&aka));
						game_field.sutehai_sarasi[hai_kind_string_to_37(result[4].substr(i,1),&aka)]++;
						i+=2;
					}
				}
				for(i=0;i<5;i++){game_field.dora[i]=-1;}
				for(i=0;i<(signed)dora.size();i++){game_field.dora[i]=dora[i];}
				int k=(signed)dora.size();
				i=result[5].find("]")+1;
				dora.clear();
				while(i<(signed)result[5].size())
				{
				  //cout<<result[5].substr(i,1)<<endl;
					if(hai_kind_string_to_33(result[5].substr(i,1),&aka)!=-1)
					{
						dora.push_back(hai_kind_string_to_33(result[5].substr(i,1),&aka));
						i++;
					}
					else
					{
						dora.push_back(hai_kind_string_to_33(result[5].substr(i,2),&aka));
						i+=2;
					}
				}
				for(i=0;i<5;i++){ura_dora[i]=-1;}
				if(k>(signed)dora.size()){k=(signed)dora.size();}
				if(k==0){ura_dora[0]=rand()%34;}
				else{for(i=0;i<k;i++){ura_dora[i]=dora[i];}}
			}
			else if((signed)result.size()>3 && result[4]=="*")
			{
				for(i=5;i<(signed)result.size();i++)
				{
				  //cout<<i<<" "<<result[i]<<endl;
				  result_paifu.push_back(result[i]);
				}
				jissai=0;
				//cout<<endl;
			}
			else if((signed)result.size()>4 && (result[4].substr(0,1)=="1"||result[4].substr(0,1)=="2"||result[4].substr(0,1)=="3"||result[4].substr(0,1)=="4"||result[4].substr(0,1)=="5"||result[4].substr(0,1)=="6"||result[4].substr(0,1)=="7"||result[4].substr(0,1)=="8"||result[4].substr(0,1)=="9"))
			{
				to_pi=toInt(result[5]);
			}
			else if(jissai==0)
			{
				jissai=1;
				int mati_flag=0;
				int pl_flag[4]={0};
				vector<int> mv_rank;
				for(i=0;i<(signed)result_paifu.size();i++)
				{
				  //cout<<i<<" "<<result_paifu.size()<<" "<<result_paifu[i]<<endl;
				  
					if(result_paifu[i].substr(1,1) == "R" && i+2<(signed)result_paifu.size() && result_paifu[i+2].substr(1,1) != "A")
					{
					  int pl=toInt( result_paifu[i].substr(0,1) )-1;				  
					  tatya[pl].ri_ti_flag=1;
					  if(tatya[pl].tenho==1){tatya[pl].ri_ti_flag=2;}//daburi
					  tatya[pl].ippatu=1;
					  tatya[pl].tensuu-=1000;
					  game_field.ri_ti_bou++;						
					  tatya[pl].ri_ti_sute=tatya[pl].sutehai.size();	  
					}
					else if(result_paifu[i].substr(1,1) == "G")
					{
						game_field.nokori_maisuu--;
						if(game_field.nokori_maisuu==0){game_field.haitei=1;}
						int pl=toInt(result_paifu[i])-1;
						tatya[pl].hai[hai_kind_string_to_33(result_paifu[i].substr(2,result_paifu[i].size()-2),&aka)]++;
						tatya[pl].aka_moti+=aka;
						if(pl==0 && mondaisuu <max_mon)
						{
							move_tsumo(tatya,&game_field,&mv_rank);
						}
					}
					else if( result_paifu[i].substr(1,1)=="D" || result_paifu[i].substr(1,1)=="d" )
					{
						int pl=toInt(result_paifu[i])-1;
						int kitta_hai=hai_kind_string_to_33(result_paifu[i].substr(2,result_paifu[i].size()-2),&aka);
						tatya[pl].hai[kitta_hai]--;
						tatya[pl].aka_moti-=aka;
						if(aka>0){game_field.mieta_aka_hai++;}
						tatya[pl].sutehai.push_back(hai_kind_string_to_37(result_paifu[i].substr(2,result_paifu[i].size()-2),&aka));
						if(result_paifu[i].substr(1,1)=="D"){tatya[pl].tedasi.push_back(0);}
						else
						{
							tatya[pl].tedasi.push_back(1);
							for(int k=0;k<34;k++)
							{if(tatya[pl].tegawari[k]<=2){tatya[pl].tegawari[k]++;}}
							tatya[pl].tegawari[kitta_hai]=0;
						}
						mae=kitta_hai;
						sutehai[kitta_hai]++;
						game_field.sutehai_sarasi[hai_kind_string_to_37(result_paifu[i].substr(2,result_paifu[i].size()-2),&aka)]++;

						tatya[pl].genbutu[kitta_hai]=1;

						for(int k=0;k<4;k++)
						{
							if(k!=pl && tatya[k].ri_ti_flag==0)
							{tatya[k].tegawari[kitta_hai]=0;}
							if(tatya[k].ri_ti_flag>=1){tatya[k].genbutu[kitta_hai]=1;}
						}
						tatya[pl].tenho=0;
						if(result_paifu[i-1].substr(1,1)!="R"){tatya[pl].ippatu=0;}
						if(game_field.kan_flag==2){game_field.dora_num++;game_field.kan_flag=0;}
						else if(game_field.kan_flag==1){game_field.kan_flag=0;}

						if(pl==0 && result_paifu[i-1].substr(1,1)=="G" && mv_rank.size()>=3 && mondaisuu <max_mon)
						{
							ofs2<<kitta_hai<<" "<<mv_rank[0]<<" "<<mv_rank[1]<<" "<<mv_rank[2]<<endl;
							cout<<kitta_hai<<" "<<mv_rank[0]<<" "<<mv_rank[1]<<" "<<mv_rank[2]<<endl;
							if(mv_rank[0]==kitta_hai){seikai[0]++;}
							else if(mv_rank[1]==kitta_hai){seikai[1]++;}
							else if(mv_rank[2]==kitta_hai){seikai[2]++;}
							mondaisuu++;
						}
					}
					else if(result_paifu[i].substr(1,1)=="N")
					{
						int pl=toInt(result_paifu[i])-1;
						if(aka>0){tatya[pl].aka_fu_ro++;game_field.mieta_aka_hai--;}
						tatya[pl].fu_ro[tatya[pl].fu_ro_suu]=mae+34;
						sutehai[mae]--;
						game_field.sutehai_sarasi[hai_kind_string_to_37(result_paifu[i-1].substr(2,result_paifu[i-1].size()-2),&aka)]--;
						tatya[pl].fu_ro_sute[tatya[pl].fu_ro_suu]=tatya[pl].sutehai.size();
						tatya[pl].fu_ro_suu++;

						int piece=(signed)result_paifu[i].size()/3;
						tatya[pl].hai[hai_kind_string_to_33(result_paifu[i].substr(2,piece),&aka)]--;
						if(aka>0){tatya[pl].aka_moti-=aka;tatya[pl].aka_fu_ro++;}
						tatya[pl].hai[hai_kind_string_to_33(result_paifu[i].substr(2+piece,piece),&aka)]--;
						if(aka>0){tatya[pl].aka_moti-=aka;tatya[pl].aka_fu_ro++;}

						for(int ip=0;ip<4;ip++){tatya[ip].ippatu=0;tatya[ip].tenho=0;}
					}
					else if(result_paifu[i].substr(1,1)=="C")
					{
						int pl=toInt(result_paifu[i])-1;
						if(aka>0){tatya[pl].aka_fu_ro++;game_field.mieta_aka_hai--;}
					
						sutehai[mae]--;
						game_field.sutehai_sarasi[hai_kind_string_to_37(result_paifu[i-1].substr(2,result_paifu[i-1].size()-2),&aka)]--;
						int kari=-1;
						kari=hai_kind_string_to_33(result_paifu[i].substr(2,2),&aka);

						tatya[pl].hai[hai_kind_string_to_33(result_paifu[i].substr(2,2),&aka)]--;
						if(aka>0){tatya[pl].aka_moti-=aka;tatya[pl].aka_fu_ro++;}
						tatya[pl].hai[hai_kind_string_to_33(result_paifu[i].substr(4,2),&aka)]--;
						if(aka>0){tatya[pl].aka_moti-=aka;tatya[pl].aka_fu_ro++;}
					
						if(mae<kari){tatya[pl].fu_ro[tatya[pl].fu_ro_suu]=mae;}
						else{tatya[pl].fu_ro[tatya[pl].fu_ro_suu]=kari;}
						tatya[pl].fu_ro_sute[tatya[pl].fu_ro_suu]=tatya[pl].sutehai.size();
						tatya[pl].fu_ro_suu++;

						for(int ip=0;ip<4;ip++){tatya[ip].ippatu=0;tatya[ip].tenho=0;}
					}
					else if(result_paifu[i].substr(1,1)=="K")
					{
						int pl=toInt(result_paifu[i])-1;
						mae=hai_kind_string_to_33(result_paifu[i].substr(2,result_paifu[i].size()-2),&aka);
						if(tatya[pl].hai[mae]==4)
						{
							if(mae<27 && mae%9==4)
							{
								if(mae/9==0){aka=1;}
								else if(mae/9==1){aka=2;}
								else if(mae/9==2){aka=4;}
								tatya[pl].aka_moti-=aka;
								tatya[pl].aka_fu_ro++;
							}
							tatya[pl].fu_ro[tatya[pl].fu_ro_suu]=mae+102;
							tatya[pl].fu_ro_sute[tatya[pl].fu_ro_suu]=tatya[pl].sutehai.size();
							tatya[pl].fu_ro_suu++;
							game_field.dora_num++;
							game_field.kan_flag=1;
						}
						else if(tatya[pl].hai[mae]==1)
						{
							if(aka>0){tatya[pl].aka_moti-=aka;tatya[pl].aka_fu_ro++;game_field.mieta_aka_hai--;}
							for(int kari=0;kari<4;kari++){if(tatya[pl].fu_ro[kari]==mae+34){tatya[pl].fu_ro[kari]+=34;}}
							game_field.kan_flag=2;
						}
						else
						{
							sutehai[mae]=0;
							game_field.sutehai_sarasi[hai_kind_string_to_37(result_paifu[i-1].substr(2,result_paifu[i-1].size()-2),&aka)]=0;
							if(aka>0){tatya[pl].aka_fu_ro++;game_field.mieta_aka_hai--;}
							tatya[pl].fu_ro[tatya[pl].fu_ro_suu]=mae+68;
							tatya[pl].fu_ro_sute[tatya[pl].fu_ro_suu]=tatya[pl].sutehai.size();
							tatya[pl].fu_ro_suu++;
							game_field.kan_flag=2;
						}
						tatya[pl].hai[mae]=0;
						if(!(i+1<(signed)result_paifu.size() && result_paifu[i+1].substr(1,1)=="A"))
					        {for(int ip=0;ip<4;ip++){tatya[ip].ippatu=0;tatya[ip].tenho=0;}}
					}
					else if(result_paifu[i].substr(1,1)=="A")
					{
					}
				}//for(i=0;i<result_paifu.size();i++)
			}//else if(jissai==0)
		}//if(yonma==1 || ( (signed)result.size()>1 && result[0]=="-----") || ((signed)result.size()>3 && jissai==1 && result[0].substr(0,5)=="====="))
	}//while(getline(ifs, str))
	
	//printf("time %d\n",(int)(-start + clock()));
	ofs<<(double)seikai[0]/(double)max_mon<<" "<<(double)(seikai[0]+seikai[1])/(double)max_mon<<" "<<(double)(seikai[0]+seikai[1]+seikai[2])/(double)max_mon<<" "<<mondaisuu<<endl;
  return 0;
}
