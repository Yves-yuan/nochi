#ifndef MA_JAN
#define MA_JAN
using namespace std;
#include <stdio.h>
#include <stdlib.h>
#include "fstream"
#include <sstream>
#include <iostream>
#include <boost/algorithm/string.hpp>
#include <boost/unordered_map.hpp>
//#include <string>
#include <cstdint>
#include <vector>
#define merusennu_N 624
#define merusennu_M 397
#define merusennu_MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_merusennu_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_merusennu_MASK 0x7fffffffUL /* least significant r bits */

extern int *shanten_list;
extern long long *uke_list;
//extern long long *uke_list1;
//boost::unordered_map<int,int> shanten_list;

int toInt(string s);
long long tolonglong(string s);
double xor01(void);
uint32_t xor32(void);

void init_genrand(unsigned long s);
void init_by_array(unsigned long init_key[], int key_length);
unsigned long genrand_int32(void);
long genrand_int31(void);
double genrand_real1(void);
double genrand_real2(void);
double genrand_real3(void);
double genrand_res53(void);
int randam(int flag);
int tenpai(int aite[],int *mati);
int kumi(int hai[],int *mentu);

double kikenhai_check(int hai[],int genbutu[],int kiruhai,int kotae[]);
inline int shantensuu(int hai[],int fu_ro);
int shantensuu_all(int hai[],int fu_ro);
int mentusuu(int hai[]);
int kantyansuu(int hai[],int mieteruhai[]);
int ryanmensuu(int hai[],int mieteruhai[],int flag);
int ryanmen_mentusuu(int hai[],int mieteruhai[],int *n,int *m);
int ryanmen_block(int hai[],int *ry,int *bl);
int titoi_shanten(int hai[],int fu_ro);
int kokusi_shanten(int hai[],int fu_ro);
int mentu_kousei(int hai[],int fu_ro,int fu_ro_bu[],int agarihai,int ron_tumo,int ri_ti,int ippatu,int bafuu,int jifuu,int haitei,int dora[],int aka,int oya,int kan,int rinshan_kaiho,int tyankan,int tenho,int han_fu[]);
int mentu_kousei2(int hai[],int fu_ro,int fu_ro_bu[],int agarihai,int ron_tumo,int ri_ti,int ippatu,int bafuu,int jifuu,int haitei,int dora[],int aka,int oya,int kan,int rinshan_kaiho,int tyankan,int tenho,int han_fu[]);
int pinfu(int check,int fu_ro,int atama,int menzen_bu[],int agarihai,int bafuu,int jifuu,int kan,int flag);
int tannyao(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan);
int i_pe_ko(int fu_ro,int menzen_bu[],int kan);
int yakuhai(int fu_ro,int menzen_bu[],int fu_ro_bu[],int bafuu,int jifuu,int kan);
int toitoi(int check,int fu_ro,int menzen_bu[],int fu_ro_bu[],int ron_tumo,int kan,int flag);
int sannannko(int fu_ro,int menzen_bu[],int ron_tumo,int check,int kan);
int tyannta(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int flag);
int junntyann(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int flag);
int honrou(int check,int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int ron_tumo,int flag);
int tinrou(int check,int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int ron_tumo,int flag);
int honnitu(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int flag);
int tinnitu(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int flag);
int sanshoku_dou_jun(int fu_ro,int menzen_bu[],int fu_ro_bu[],int kan);
int sanshoku_dou_kou(int fu_ro,int menzen_bu[],int fu_ro_bu[],int kan);
int ittuu(int fu_ro,int menzen_bu[],int fu_ro_bu[],int kan);
int shou_sann_genn(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int flag);
int tyuurenn(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int flag);
int tu_i_so(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan);
int dai_su_si(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan);
int ryuu_i_so(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan);
int su_kann_tu(int fu_ro,int menzen_bu[],int fu_ro_bu[],int atama,int kan,int flag);
int ri_ti_check(int ri_ti);
int tumo_check(int fu_ro,int ron_tumo);
int ippatu_check(int ippatu);
int haitei_check(int haitei,int ron_tumo,int rinshan_kaiho);
int rinshan_kaiho_check(int rinshan_kaiho);
int tyankan_check(int tyankan);
int tenho_check(int tenho,int ron_tumo,int oya);
int tu_i_so_ti_toi(int hai[]);
int tanyao_ti_toi(int hai[]);
int honrou_ti_toi(int hai[]);
int honitu_ti_toi(int hai[]);
int dora_check(int fu_ro,int atama,int menzen_bu[],int fu_ro_bu[],int kan,int dora[],int aka);
int tensuu(int hansuu,int fu,int oya ,int ron_tumo);
int yaku_check(int fu_ro,int atama,int menzen_bu[],int fu_ro_bu[],int agarihai,int ron_tumo,int ri_ti,int ippatu,int bafuu,int jifuu,int haitei,int dora[],int aka,int oya,int kan,int rinshan_kaiho,int tyankan,int tenho,int han_fu[]);
int yaku(int hai[],int fu_ro_bu[],int agarihai,int ron_tumo,int ri_ti,int ippatu,int bafuu,int jifuu,int haitei,int dora[],int aka,int rinshan_kaiho,int tyankan,int tenho,int han_fu[]);;
int hai_check(int hai[]);
int ukihai_x(int hai[],int x);
int ukihai_check(int hai[],int *x);
int tumo(int a[]);
int shanten_maisuu(int hai[],int mieteruhai[],int x,int n,int fu_ro);
int henka(int hai[],int mieteruhai[],int *n,int x,int fu_ro);
int ukeire_check(int hai[],int mieteruhai[],int x,int fu_ro);
int tarts_over_check(int hai[]);
int tarts_count_max(int hai[]);
int matitori(int hai[],int matitori[],int fu_ro);
double kitai_houjuu_ten(int dora,int kiri_dora,int ri_ti,int fu_ro,int fu_ro_bu[],int fu_ro_aka[],int kaze,int mieterudora);
double tenpai_prob(int junme,int fu_ro,int tedasi,int ri_ti);
int genbutu_check(int mati[],int shurui,int sutehai[],int sutehai_suu,int pre_genbutu[],int pre_genbutu_suu,int hai[]);
int hai_count(int count[],int what,int dora,int dora_hyouji,int hai[],int tehai_aka,int fu_ro_bu0[],int fu_ro_bu1[],int fu_ro_bu2[],int fu_ro_bu3[],int fu_ro_aka0[],int fu_ro_aka1[],int fu_ro_aka2[],int fu_ro_aka3[],int sutehai0[],int sutehai1[],int sutehai2[],int sutehai3[],int sutehai_suu[]);
int tokuten_sim(int jibun,int simotya,int toimen,int kamitya,int kyoku,int honba,int ri_ti_bou,int oya,int tonnan,double junibunnpu[]);
int saisoku_tenpai_ver4(int hai[],int mieteruhai[],int junme,int simulation,int fu_ro);
void init(string filename);
string IntToString(int number);
double string2double(const std::string& str);
std::string DoubletoString(double number);
int get_kind_of_dora(int i);
int block(int hai[]);
int deagari(int tensa,int sekijun,int oya,int aite_oya,int ri_ti_bou,int honba);//�����܂��͑Ώۂ̃v���C���������烍������
int tsumo_agari(int tensa,int sekijun,int oya,int aite_oya,int ri_ti_bou,int honba);//�����܂��͑Ώۂ̃v���C�����c��
int chokugeki(int tensa,int sekijun,int oya,int aite_oya,int ri_ti_bou,int honba);//�����ƑΏۂ̃v���C��������������
int waki_tsumo(int tensa,int sekijun,int oya,int aite_oya,int ri_ti_bou,int honba);//�e���c��
int ryuukyoku(int tensa,int sekijun);//���ǂ����Ƃ�
int trance37to34(int i);
int trance34to37(int i);
int check_nakeru(int hai[],int hai_kind,int dare);
int hai_kind_string_to_33(string s,int *aka);
int hai_kind_string_to_37(string s,int *aka);
#endif//ma_jan