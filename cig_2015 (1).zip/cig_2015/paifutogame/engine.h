﻿#ifndef _OPM_
#define _OPM_
#include "ma_jan.h"
struct player
{
 int fu_ro_suu;
 int fu_ro[4];
 int aka_fu_ro;
 int aka_moti;
 int ri_ti_flag;
 int ri_ti_sute;
 int fu_ro_sute[4];
 int ippatu;
 int tenho;
       
 int tensuu;
 vector<int> sutehai;//37
 vector<int> tedasi;
 int tegawari[34];
 int genbutu[34];
 int hai[34];
 int jifuu;
 int fold_flag;
};
struct field
{
 int bafuu;
 int kyoku;
 int game_long;
 int ri_ti_bou;
 int honba;
 int dora[5];
 int dora_num;
 int haitei;
 int kan_flag;

 int dora_basho;
 int nokori_maisuu;
 int sutehai_sarasi[37];
 int mieta_aka_hai;
};


//tenpai_pre
extern double **tenpai_wei;
void tenpai_pre_feature(int pl,int mirugawa,player p[],field *f,int sutehai[],vector<string> *feature,vector<double> *feature_val);
int init_tenpai_pre_weight();
void cal_tenpai_pro(double tenpai_pro[],double **tenpai_wei,int pl,player tatya[],field *game_field,int sutehai[]);

//matiyomi
extern double **matiyomi_wei;
void combi(int mieteruhai[],int anzen,int genbutu[],double kumiawase[]);
int init_mati_weight();
void matiyomi_feature(int mieteruhai[],int pl,int mirugawa,player tatya[],field *game_field,vector<string> *feature,vector<double> *feature_val);
void cal_matiyomi_pro(boost::unordered_map<string,double> &matiyomi_pro,double **matiyomi_wei,int pl,player tatya[],field *game_field,int mieteruhai[]);

//tokuten_pre
int init_tokuten_pre_weight();
void make_mieteruhai(int pl,player tatya[],int mieteruhai[],int sutehai[]);
int mieteru_dora(int mieteruhai[],player tatya[],field *game_field);
void tokuten_pre_feature(int pl,int mirugawa,int ron_tsumo,int agarihai,player p[],field *f,int mieteruhai[],vector<string> *feature,vector<double> *feature_val);
void cal_tokuten_pro(boost::unordered_map<string,double> &tokuten_pro,double *tokuten_wei,int pl,player tatya[],field *game_field,int mieteruhai[]);

void init_engine();

//int make_feature_pl(player tatya[],field *game_field,int mieteruhai[]);
int mieteru_dora(int mieteruhai[],player tatya[],field *game_field);
int sarasi_dora(player a,field *game_field);
void make_mieteruhai(int pl,player tatya[],int mieteruhai[],int sutehai[]);
int ukeire_bit(int hai[],int fu_ro,int ukeire[]);
int frtn(int hai[],int genbutu[],int pai,int fu_ro);
int hai_naki_nuku(int hai[],int hai_copy[],int fu_ro[],int fu_ro_copy[],int pai,int kind);
int naki_check_push_pattern(int hai[],int player,int aite,int pai,vector<int> *naki_pattern);
int cut_aka(int hai[],int pai,int aka_moti);
int get_number_of_aka(int aka_moti);
int get_number_of_dora2(int hai[],int fu_ro[],field *game_field);
int get_number_of_ura_dora(player tatya[],vector<int> ura);
double cal_seme_pro(int pl,player tatya[],int jun,int sp[],int tenpai[]);
int make_feature(player tatya[],field *game_field,int mieteruhai[]);

int move_tsumo(player tatya[],field *game_field,vector<int> *mv_rank);
int move_naki(int hai[],int mae_kind,int naki_hai[],player tatya[],field *game_field,int dare,int aka,int *out);

int op_move(player tatya[],field *game_field,int mieteruhai[]);
int op_move2(player tatya[],field *game_field,int mieteruhai[],vector<int> *mv_rank);
int op_move_naki(player tatya[],field *game_field,int mieteruhai[],int mae_kind,int dare,int aka);
void make_tumo_rand(player tatya[],field *game_field,int mieteruhai[],vector<int> *yama,vector<int> *sute,vector<int> *aka_yama,vector<double> *ra,vector<int> *ura,int sp[],double tenpai[3][18],double fold[3][18]);
double one_turn_expect(int move,player tatya[],field *game_field,int mieteruhai[],int sp[],int tenpai[],int fold[],double pass_pro[3][34],double tktn[9][35],vector<int> ura,double fv[],double fv_pr[]);
double game_sim(int pl,player tatya[],field *game_field,int mieteruhai[],int ankan,double pass_pro[3][34],double tktn[9][35],double tenpai_pro[],double tenpai_add[2][18],double fv[],double fv_pr[],vector<int> *yama,vector<double> *ra,vector<int> ura,vector<int> *aka_yama,int sp[3],double fold[3][18],double tenpai_ary[3][18],int fold_flag[3],int tenpai[3],int *reult_type);
int monte(player tatya[],field *game_field,int mieteruhai[],double pass_pro[3][34],double tktn[9][35],double tenpai_pro[],vector<int> *kouho,vector<double> *exp,double fv[],double fv_pr[],int thread_num);
int monte_naki(int pl,player tatya[],field *game_field,int mieteruhai[],double pass_pro[3][34],double tktn[9][35],double tenpai_pro[],int mae_kind,int dare,int aka,vector<int> *gouhoushu,vector<double> *exp,double fv[],double fv_pr[],int thread_num);
double fold_value(int pl,player tatya[],field *game_field,int mieteruhai[],double pass_pro[3][34],double tktn[9][35],double tenpai_pro[],double fv[],double fv_pr[]);
#endif